import WhetherSwitch from './whether-switch.vue'
export default WhetherSwitch
