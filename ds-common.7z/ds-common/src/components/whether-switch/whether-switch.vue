<template>
    <i-switch ref="Switch" :value="value" @on-change="handleChange" :class="clz" :true-value="1" :false-value="0">
        <span slot="open">是</span>
        <span slot="close">否</span>
    </i-switch>
</template>

<script>
    import {iSwitch} from 'view-design';
    export default {
        name: 'WhetherSwitch',
        components: {
            iSwitch
        },
        model: {
            prop: 'value',
            event: 'change'
        },
        props: {
            value: {
                type: String,
                default: '0'
            },
            clz: {
                type: String
            }
        },
        computed: {},
        methods: {
            handleChange(selected) {
                this.$emit('change', selected)
            }
        }
    }
</script>

<style>

</style>
