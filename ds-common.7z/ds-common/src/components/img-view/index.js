import ImgView from './img-view.vue'
export default ImgView
