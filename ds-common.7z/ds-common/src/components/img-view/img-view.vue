<template>
    <Modal :z-index="9999" :title="title" v-model="imgShow" @on-cancel="handleCancel" :width="fullscreen ? 100 : 60" :fullscreen="fullscreen" transfer>
        <img :src="curUrl" v-if="imgShow" style="width: 100%">
        <slot></slot>
        <div slot="footer">
        </div>
    </Modal>
</template>
<script>
    import fileUploadUtil from '../files-upload/upload'
    export default {
        components: {},
        name: 'ImgView',
        props: {
            value: {
                type: Boolean,
                default: false
            },
            fileId: {
                type: [Number, String]
            },
            title: {
                type: String,
                default: '查看'
            },
            fullscreen: {
                type: Boolean,
                default: false
            }
        },
        data() {
            return {
                imgShow: this.value,
                curUrl: fileUploadUtil.IMG_VIEW_URL + this.fileId,
            }
        },
        watch: {
            value(val) {
                this.imgShow = val
            },
            fileId(val) {
                this.curUrl = fileUploadUtil.IMG_VIEW_URL + this.fileId
            }
        },
        methods: {
            handleCancel(e) {
                this.imgShow = false
                this.$emit('update:value', false)
                this.$emit('on-cancel')
            }
        },
        mounted() {}
    }
</script>
<style lang="less" scoped>

</style>
