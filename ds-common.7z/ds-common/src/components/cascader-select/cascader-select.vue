<template>
    <div>
        <Cascader :data="regionData" v-model="curVal" trigger="hover" @on-change="handleChange" :disabled="disabled"
                  transfer></Cascader>
    </div>
</template>

<script>
    import {Cascader} from "view-design";
    import {ApiUtils} from "multi-tenant-common";

    export default {
        name: "CascaderSelect",
        components: {
            Cascader
        },
        model: {
            prop: "value",
            event: "change"
        },
        props: {
            value: {
                type: [String, Number],
                default: ""
            },
            disabled: {
                type: Boolean,
                default: false
            }
        },
        computed: {},
        data() {
            return {
                curVal: this.value ? (this.value + '').split(',') : [],
                regionData: []
            };
        },
        watch: {
            value(val) {
                this.curVal = val ? (val + '').split(',') : []
            }
        },
        methods: {
            regionListHttp() {
                var vm = this;
                vm.$request({
                    url: "/api/v1/province/query-province-list",
                    data: {},
                    success: res => {
                        if (res.data.regionList && res.data.regionList.length > 0) {
                            vm.regionData = res.data.regionList.map(item => {
                                item.value = item.provinceId + ''
                                item.label = item.provinceName
                                if (item.children && item.children.length > 0) {
                                    item.children = item.children.map(c => {
                                        c.value = c.provinceId + ''
                                        c.label = c.provinceName
                                        return c
                                    })
                                }
                                return item
                            })
                        }
                    }
                });
            },

            handleChange(index, selected) {
                let val = selected[selected.length - 1].__value + '';
                this.curVal = val.split(',')
                this.$emit("change", val);
                this.$emit("on-change", selected);
            }
        },
        created() {
            this.regionListHttp();
        }
    };
</script>

<style>
    .product-checkbox {
        height: 40px;
        line-height: 2.5;
    }
</style>
