import AmapAddress from './amap-address.vue'
export default AmapAddress
