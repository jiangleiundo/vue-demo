<template>
    <div class="form-block">
        <Row v-if="pcaFlag">
            <Col span="24">
                <label v-if="viewFlag" v-text="valueToText(selectPca,'pca')"></label>
                <Cascader v-else :data="pca" v-model="selectPca" placeholder="请选择省市区街道" class="form-block"
                          @on-change="handleChange"></Cascader>
            </Col>
        </Row>
        <Row v-if="addressFlag">
            <Col span="24">
                <label v-if="viewFlag" v-text="currentAddress"></label>
                <Input v-else v-model="currentAddress" @input="addressChange" placeholder="请输入详细地址"
                       class="form-block ad-address"></Input>
            </Col>
        </Row>
        <Row v-if="mapFlag">
            <Col span="12">
                <label v-text="`经度：${currentLng || ''}`"></label>
            </Col>
            <Col span="12">
                <label v-text="`纬度：${currentLat || ''}`"></label>
            </Col>
        </Row>
        <Row v-if="mapFlag">
            <Col span="24">
                <div :id="mapId" class="form-block ad-map"></div>
            </Col>
        </Row>
    </div>
</template>

<script>
    import {Row, Col, Input, Cascader} from 'view-design';
    import {valueToText} from '../../libs/api.utils'
    import pca from '../../libs/pca'
    import MapLoader from '../../assets/js/AMap.js'
    import markPng from '../../assets/image/mark.png'

    export default {
        name: 'AmapAddress',
        components: {
            Row,
            Col,
            Input,
            Cascader
        },
        props: {
            value: {
                type: Array
            },
            mapId: {
                type: String,
                required: true
            },
            address: {
                type: String
            },
            view: {
                type: Boolean,
                default: false,
            },
            noPca: {
                type: Boolean,
                default: false
            },
            noMap: {
                type: Boolean,
                default: false
            },
            addressFlag: {
                type: Boolean,
                default: true
            },
            // 经度
            lng: {
                type: Number
            },
            // 纬度
            lat: {
                type: Number
            },
            zoom: {
                type: Number,
                default: 12
            }
        },
        computed: {},
        components: {
            'amap': 'el-amap'
        },
        data() {
            return {
                valueToText: valueToText,
                pca: pca,
                viewFlag: this.view,
                mapFlag: !this.noMap,
                pcaFlag: !this.noPca,
                selectPca: this.value,
                currentAddress: this.address,
                currentLng: this.lng,
                currentLat: this.lat,
                currentZoom: this.zoom,
                map: null,
                marker: null
            }
        },
        watch: {
            value(val) {
                this.selectPca = val
            },
            address(val) {
                this.currentAddress = val
            },
            lng(val) {
                this.currentLng = val
                if (!this.map) {
                    this.mapInit()
                }
            },
            lat(val) {
                this.currentLat = val
                if (!this.map) {
                    this.mapInit()
                }
            },
            zoom(val) {
                this.currentZoom = val
            }
        },
        methods: {
            handleChange(value, selectedData) {
                let vm = this
                if (value) {
                    vm.selectPca = value
                    vm.setCity()
                    vm.$emit('pca-change', value, selectedData)
                }
            },
            addressChange(value) {
                if (value) {
                    this.currentAddress = value
                }
                this.$emit('address-change', value)
            },
            mapClick(e) {
                let vm = this
                vm.currentLng = e.lnglat.lng // 经度
                vm.currentLat = e.lnglat.lat // 纬度
                vm.marker.setPosition([vm.currentLng, vm.currentLat])
                vm.$emit('map-click', vm.currentLng, vm.currentLat)
            },
            setCity: function () {
                let vm = this
                if (!this.map) {
                    vm.currentLng = vm.currentLng || 116.405285
                    vm.currentLat = vm.currentLat || 39.904989
                    vm.mapInit()
                }
                if (vm.selectPca.length === 3) {
                    this.map.setCity(vm.selectPca[2], e => {
                        vm.marker.setPosition(e)
                        vm.currentLng = e[0]
                        vm.currentLat = e[1]
                    })
                } else if (vm.selectPca.length === 4) {
                    this.map.setCity(vm.selectPca[3], e => {
                        vm.marker.setPosition(e)
                        vm.currentLng = e[0]
                        vm.currentLat = e[1]
                    })
                }
            },
            mapInit: function () {
                let vm = this
                if (vm.currentLng && vm.currentLat) {
                    let center = [vm.currentLng, vm.currentLat]
                    // 初始化地图
                    vm.map = new window.AMap.Map(vm.mapId, {
                        center: center,
                        zoom: vm.currentZoom
                    })

                    // 初始化点
                    vm.marker = new window.AMap.Marker({
                        icon: markPng,
                        position: center
                    });
                    vm.map.add(vm.marker)

                    // 监听地图单击事件
                    if (!vm.viewFlag) {
                        vm.map.on('click', vm.mapClick);
                    }
                    console.log('地图[' + vm.mapId + ']加载成功')
                }
            },
            destroy() {
                if (this.map) {
                    this.map.destroy()
                    this.map = null
                    this.marker = null
                    console.log('地图[' + this.mapId + ']销毁成功')
                }
            }
        },
        mounted: function () {
            let vm = this
            if (window.AMap) {
                vm.mapInit()
            } else {
                MapLoader().then(AMap => {
                    window.AMap = AMap
                    vm.mapInit()
                }, e => {
                    console.log('地图加载失败', e)
                })
            }
        },
        destroyed() {
            this.destroy()
            window.AMap = null
        }
    }
</script>

<style>
    .ad-map {
        height: 300px;
        margin-top: 10px;
        border-width: 1px;
    }

    .ad-address {
        margin-top: 10px;
    }
</style>
