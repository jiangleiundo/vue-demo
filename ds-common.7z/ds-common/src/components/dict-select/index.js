import DictSelect from './dict-select.vue'
export default DictSelect
