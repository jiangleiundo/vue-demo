<template>
  <Poptip :trigger="trigger" :placement="placement" transfer>
    <a>{{ product.productName }}</a>
    <Card slot="content" class="product-card">
      <Row>
        <Col span="12">
          <span class="product-span">
            <b>业务模式：</b>
            {{ product.modeName }}
          </span>
        </Col>
        <Col span="12">
          <span class="product-span">
            <b>违约金计收标准：</b>
            {{valueToText(product.penalSumRate, 'thousandRate')}}
          </span>
        </Col>
      </Row>
      <Row>
        <Col span="12">
          <span class="product-span">
            <b>利率：</b>
            {{valueToText(product.rate, 'rate')}}
          </span>
        </Col>
        <Col span="12">
          <span class="product-span">
            <b>展期利率倍数：</b>
            {{valueToText(product.penaltyRate, 'rate')}}
          </span>
        </Col>
      </Row>
      <Row>
        <Col span="12">
          <span class="product-span">
            <b>保理费率：</b>
            {{valueToText(product.factoringRate, 'rate')}}
          </span>
        </Col>
        <Col span="12">
          <span class="product-span">
            <b>最低保理费金额：</b>
            {{valueToText(product.minFactoringAmt, 'money')}}
          </span>
        </Col>
      </Row>
      <Row>
        <Col span="12">
          <span class="product-span">
            <b>产品期限(月)：</b>
            {{ product.productLimit }}
          </span>
        </Col>
        <Col span="12">
          <span class="product-span">
            <b>宽限期(天)：</b>
            {{ product.productGraceLimit }}
          </span>
        </Col>
      </Row>
      <Row>
        <Col span="12">
          <span class="product-span">
            <b>违约判断天数：</b>
            {{ product.penaltyJudgeDays }}
          </span>
        </Col>
        <Col span="12">
          <span class="product-span">
            <b>是否允许提前还款：</b>
            {{valueToText(product.allowPrepayment, 'dict', 'YES_NO')}}
          </span>
        </Col>
      </Row>
      <Row>
        <Col span="12">
          <span class="product-span">
            <b>还款方式：</b>
            {{ buildRepayType(product) }}
          </span>
        </Col>
      </Row>
    </Card>
  </Poptip>
</template>

<script>
import { Row, Col, Poptip, Card } from "view-design";
import { ApiUtils } from "multi-tenant-common";

export default {
  name: "ProductTip",
  components: {
    Row,
    Col,
    Poptip,
    Card
  },
  props: {
    value: {
      type: Object,
      default: () => {
        return {};
      }
    },
    trigger: {
      type: String,
      default: "hover"
    },
    placement: {
      type: String,
      default: "right"
    }
  },
  data() {
    return {
      valueToText: ApiUtils.valueToText,
      product: this.value,
    };
  },
  computed: {},
  watch: {
    value(val) {
      this.product = val;
    }
  },
  methods: {
    buildRepayType(product) {
      let msg = "";
      if (product && product.repayType) {
        if (product.repayType == "0") {
          msg = "利随本清";
        } else if (product.repayType == "1") {
          msg = "按月付息到期还款";
        } else if (product.repayType == "2") {
          msg = "按季付息到期还款";
        } else if (product.repayType == "3") {
          msg = "到期前" + product.beforeNNo + "月回款就扣";
        }
      }
      return msg;
    }
  }
};
</script>

