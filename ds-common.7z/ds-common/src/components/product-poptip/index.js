import ProductPoptip from './product-poptip.vue'
export default ProductPoptip
