import ImgUpload from './img-upload.vue'
export default ImgUpload
