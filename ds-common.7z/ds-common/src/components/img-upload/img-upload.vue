<template>
    <Upload
        :action=action
        name="file"
        :show-upload-list="false"
        :on-success="handleSuccess"
        :format="['jpg','jpeg','png']"
        :max-size="2048">
        <div style="width:200px;height:200px;border: 1px dashed #dddee1;text-align: center;">
            <Button v-show="!imgUrl" icon="ios-cloud-upload-outline" style="margin: 80px 0;">上传
            </Button>
            <img v-if="imgUrl" :src="imgUrl" :alt="imgAlt"
                 style="position: absolute;width:100%;height:100%;cursor:pointer;margin: 0px 0 0 -100px;"/>
        </div>
    </Upload>
</template>

<script>
    import {Upload, Button} from 'view-design';
    export default {
        name: 'ImgUpload',
        components: {
            Upload,
            Button
        },
        props: {
            value: {
                type: String
            },
            action: {
                type: String,
                default: '/api/admin/file/upload'
            },
            imgAlt: {
                type: String,
                default: '图片'
            }
        },
        computed: {},
        data() {
            return {
                imgUrl: this.value
            }
        },
        watch: {
            value(val) {
                this.imgUrl = val;
            }
        },
        methods: {
            handleSuccess: function (res, file) {
                this.imgUrl = res.data
                this.$emit('on-upload', res.data, res, file)
            }
        },
        mounted: function () {
        }
    }
</script>

<style>

</style>
