<template>
    <div>
        <Button v-if="currentValue && currentValue.length > 0" type="text" @click="handleView"><Icon custom="iconfont icon-view" size="18"></Icon></Button>
        <Modal :title="title" v-model="filesShow" @on-cancel="handleCancel" width="50" transfer>
            <FilesUpload v-model="currentValue" viewFlag></FilesUpload>
        </Modal>
    </div>
</template>
<script>
    import {Modal, Button} from 'view-design'
    import FilesUpload from '../files-upload'
    import fileUploadUtil from '../files-upload/upload'
    export default {
        components: {
            Modal, Button, FilesUpload
        },
        name: 'FilesView',
        props: {
            value: {
                type: [String, Number, Array],
                default: () => {
                    return []
                }
            },
            title: {
                type: String,
                default: '文件查看'
            },
            fullscreen: {
                type: Boolean,
                default: false
            }
        },
        data() {
            return {
                filesShow: false,
                currentValue: this.value
            }
        },
        watch: {
            value(val) {
                this.currentValue = val
            }
        },
        methods: {
            handleView() {
                this.filesShow = true
            },
            handleCancel(e) {
                this.filesShow = false
            }
        },
        mounted() {}
    }
</script>
<style lang="less" scoped>

</style>
