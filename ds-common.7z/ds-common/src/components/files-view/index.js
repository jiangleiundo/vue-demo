import FilesView from './files-view.vue'
export default FilesView
