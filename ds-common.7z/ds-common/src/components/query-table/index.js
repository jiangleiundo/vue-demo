import QueryTable from './query-table.vue'
export default QueryTable
