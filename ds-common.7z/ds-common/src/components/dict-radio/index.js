import DictRadio from './dict-radio.vue'
export default DictRadio
