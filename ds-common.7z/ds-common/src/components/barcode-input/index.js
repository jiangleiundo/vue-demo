import BarcodeInput from './barcode-input.vue'
export default BarcodeInput
