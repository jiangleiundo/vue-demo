<template>
    <div style="height: 200px">
        <Input v-if="!view" :value="value" @input="handleChange" :class="clz"></Input>
        <img id="barcode"/>
    </div>
</template>

<script>
    import {Input} from 'view-design'
    import jsbarcode from 'jsbarcode'

    export default {
        name: 'BarcodeInput',
        components: {
            Input
        },
        model: {
            prop: 'value',
            event: 'input'
        },
        props: {
            view: {
                type: Boolean,
                default: false
            },
            value: {
                type: String
            },
            placeholder: {
                type: String
            },
            clz: {
                type: String
            }
        },
        computed: {},
        data() {
            return {}
        },
        watch: {
            value(val) {
                if (val) {
                    this.barcode(val)
                }
            }
        },
        methods: {
            barcode(value) {
                // 详细配置信息：https://github.com/lindell/JsBarcode/wiki/Options
                try {
                    // 尝试 EAN8 码执行
                    jsbarcode("#barcode", value, {
                        format: 'EAN8'
                    });
                } catch (e) {
                    try {
                        // 尝试 EAN13 码执行
                        jsbarcode("#barcode", value, {
                            format: 'EAN13'
                        });
                    } catch (e) {
                        // 默认执行
                        jsbarcode("#barcode", value);
                    }
                }
            },
            handleChange(value) {
                if (value) {
                    this.barcode(value)
                }
                this.$emit('change', value)
            }
        }
    }
</script>

<style>

</style>
