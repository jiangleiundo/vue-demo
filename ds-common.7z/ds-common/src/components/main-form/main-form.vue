

<template>
    <div>
        <Drawer v-if="formStyle=='1'" :title="currentTitle" v-model="formShow" :width="width" :mask-closable="false"
                :placement="placement" @on-close="handleCancel">
            <slot name="other-main"></slot>
            <Form ref="formMain" :model="currentData" :rules="rules" :label-width="labelWidth" class="form-warp" :disabled="currentDisabled" inline>
                <slot name="form-main"></slot>
                <Tabs v-if="tabStyle==='1' && currentTabList.length>0" type="card" v-model="currentIndex" @on-click="tabClick">
                    <TabPane v-for="(name, index) in currentTabList" :label="name">
                        <slot :name="`form-tab-${index}`"></slot>
                    </TabPane>
                </Tabs>
                <Collapse v-if="tabStyle==='2' && currentTabList.length>0" :value="tabShow">
                    <Panel v-for="(name, index) in currentTabList">
                        {{name}}
                        <div slot="content">
                            <slot :name="`form-tab-${index}`"></slot>
                        </div>
                    </Panel>
                </Collapse>
            </Form>
            <div v-if="$slots['form-btn']" class="drawer-footer">
                <slot name="form-btn"></slot>
            </div>
        </Drawer>
        <Modal v-if="formStyle=='2'" :title="currentTitle" v-model="formShow" :width="width" :mask-closable="false"
               :fullscreen="fullscreen" @on-cancel="handleCancel" transfer>
            <slot name="other-main"></slot>
            <Form ref="formMain" :model="currentData" :rules="rules" :label-width="labelWidth" class="form-warp" :disabled="currentDisabled" inline>
                <slot name="form-main"></slot>
                <Tabs v-if="tabStyle==='1' && currentTabList.length>0" type="card" v-model="currentIndex" @on-click="tabClick">
                    <TabPane v-for="(name, index) in currentTabList" :label="name">
                        <slot :name="`form-tab-${index}`"></slot>
                    </TabPane>
                </Tabs>
                <Collapse v-if="tabStyle==='2' && currentTabList.length>0" :value="tabShow">
                    <Panel v-for="(name, index) in currentTabList">
                        {{name}}
                        <div slot="content">
                            <slot :name="`form-tab-${index}`"></slot>
                        </div>
                    </Panel>
                </Collapse>
            </Form>
            <div v-if="$slots['form-btn']" slot="footer">
                <slot name="form-btn"></slot>
            </div>
        </Modal>
        <div v-if="formStyle=='3'">
            <slot name="other-main"></slot>
            <Form ref="formMain" :model="currentData" :rules="rules" :label-width="labelWidth" class="form-warp" :disabled="currentDisabled" inline>
                <slot name="form-main"></slot>
                <Tabs v-if="tabStyle==='1' && currentTabList.length>0" style='margin-left:20px' type="card" v-model="currentIndex" @on-click="tabClick">
                    <TabPane v-for="(name, index) in currentTabList" :label="name">
                        <slot :name="`form-tab-${index}`"></slot>
                    </TabPane>
                </Tabs>
                <Collapse v-if="tabStyle==='2' && currentTabList.length>0" :value="tabShow">
                    <Panel v-for="(name, index) in currentTabList">
                        {{name}}
                        <div slot="content">
                            <slot :name="`form-tab-${index}`"></slot>
                        </div>
                    </Panel>
                </Collapse>
            </Form>
            <div v-if="$slots['form-btn']" slot="footer" class="form-footer">
                <slot name="form-btn"></slot>
            </div>
        </div>
    </div>
</template>
<script>
    import {Drawer, Tabs, TabPane, Collapse, Panel, Modal} from 'view-design';
    import {themeRead} from '../../libs/util'
    import Form from '../form'
    import store from '@/store'
    import config from '@/config'

    export default {
        name: 'MainForm',
        components: {
            Drawer,
            Tabs,
            TabPane,
            Collapse,
            Panel,
            Modal,
            Form
        },
        props: {
            value: {
                type: Boolean,
                default: false
            },
            title: {
                type: String,
                default: ''
            },
            width: {
                type: [Number, String],
                default: 80
            },
            data: {
                type: Object,
                default: () => {
                    return {}
                }
            },
            rules: {
                type: Object,
                default: () => {
                    return {}
                }
            },
            labelWidth: {
                type: Number,
                default: 120
            },
            tabType: {
                type: String
            },
            /**
             * 分栏展示，index,name
             */
            tabList: {
                type: Array,
                default: () => {
                    return []
                }
            },
            tabShow: {
                type: Array,
                default: () => {
                    return [0]
                }
            },
            placement: {
                type: String,
                default: 'right'
            },
            formType: {
                type: [String, Number]
            },
            disabled: {
                type: Boolean,
                default: false
            },
            index: {
                type: [String, Number],
                default: 0
            },
            fullscreen: {
                type: Boolean,
                default: false
            }
        },
        data() {
            return {
                theme: '',
                formStyle: this.formType || '1',
                tabStyle: this.tabType || '1',
                formShow: this.value,
                currentTitle: this.title,
                currentData: this.data,
                currentTabList: this.tabList,
                currentDisabled: this.disabled,
                currentIndex: this.index
            }
        },
        watch: {
            value(val) {
                if(val) {
                    if(config.checkLogin) store.dispatch('handleCheckLogin')
                } else {
                    this.currentIndex = 0
                    this.$refs.formMain.resetFields()
                }
                this.formShow = val
            },
            title(val) {
                this.currentTitle = val
            },
            data(val) {
                this.currentData = val
            },
            tabList(val) {
                this.currentTabList = val
            },
            disabled(val) {
                this.currentDisabled = val
            },
            index(val) {
                this.currentIndex = val
            }
        },
        methods: {
            setTheme() {
                this.theme = themeRead()
                // 抽屉
                if (!this.formStyle) {
                    if (this.theme === '3' || this.theme === '4') {
                        this.formStyle = '1'
                    } else { // 弹出
                        this.formStyle = '2'
                    }
                }
                // tab
                if (!this.tabStyle) {
                    if (this.theme === '2' || this.theme === '4') {
                        this.tabStyle = '1'
                    } else { // 手风琴
                        this.tabStyle = '2'
                    }
                }
            },
            validate(callback) {
                return this.$refs.formMain.validate(callback)
            },
            handleCancel(e) {
                this.formShow = false
                this.$emit('update:value', false)
                this.$emit('on-cancel')
            },
            tabClick(name) {
                this.currentIndex = name
                this.$emit('update:index', name)
                this.$emit('on-tab-click', name)
            },
            resetFields() {
                this.$refs.formMain.resetFields();
            }
        },
        created() {
            // this.setTheme()
        },
        mounted() {

        }
    }
</script>

<style lang="less" scoped>
    .ivu-modal{
        margin: 0 auto 100px !important;
    }
</style>
