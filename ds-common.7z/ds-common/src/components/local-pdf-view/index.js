import LocalPdfView from './local-pdf-view.vue'
export default LocalPdfView
