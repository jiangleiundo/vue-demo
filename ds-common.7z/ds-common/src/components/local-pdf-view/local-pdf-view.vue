<template>
    <Modal :title="title" v-model="pdfShow" @on-cancel="handleCancel" width="60" :z-index='index' :fullscreen="fullscreen" :mask-closable='maskClosable'>
        <iframe v-if="pdfShow" :src="curUrl" style="width: 100%;height: 750px;border: medium none"></iframe>
        <slot name="form-input"></slot>
        <div slot="footer">
        </div>
    </Modal>
</template>
<script>
import {Button } from "view-design";
    export default {
        components: {
            Button
        },
        name: 'LocalPdfView',
        props: {
            value: {
                type: Boolean,
                default: false
            },
            url: {
                type: String
            },
            title: {
                type: String,
                default: '查看'
            },
            fullscreen: {
                type: Boolean,
                default: false
            },
            maskClosable:{
                type:Boolean,
                default:true
            },
            index:{
                type:Number,
                default:1000
            }
        },
        data() {
            return {
                pdfShow: this.value,
                curUrl: $BASE_URL + this.url,
            }
        },
        watch: {
            value(val) {
                this.pdfShow = val
            },
            url(val) {
                this.curUrl = $BASE_URL + this.val
            }
        },
        methods: {
            handleCancel(e) {
                this.pdfShow = false
                this.$emit('update:value', false)
                this.$emit('on-cancel')
            },
        },
        mounted() {}
    }
</script>
<style  scoped>

</style>
