<template>
    <TablesSummary ref="tables" :loading="isTableLoading" v-model="mainTable" :columns="tableColumns" :summaryKill="summaryKill"
            :total="mainList.total" :current="mainList.page" :page-size="mainList.pageSize" :showSummary="showSummary"
            :isShowData="isShowData" :summaryInt="summaryInt"
            @on-search="query"
            @on-change="changePage(mainList, $event)"
            @on-page-size-change="changePageSize(mainList, $event)"
            @on-refresh="refresh"
            @on-selection-change="handleSelect">
        <div slot="search-form" class="search-form">
            <slot name="search-form"></slot>
        </div>
        <div slot="show-data" class="search-form">
            <slot name="show-data"></slot>
        </div>

        <div slot="search-btn" class="search-form" v-if="exportData">
            <Button type="primary" @click="handleExport">excel导出</Button>
        </div>
    </TablesSummary>
</template>

<script>
    import {Button} from 'view-design'
    import Tables from '../tables'
    import TablesSummary from '../tables-summary'
    import {$http, isRepeatClick} from '../../libs/api.utils'

    export default {
        name: "QueryTable",
        components: {
            Tables, Button, TablesSummary
        },
        props: {
            tableColumns: {
                type: Array,
                default() {
                    return []
                }
            },
            liveTableColumns: {
                type: Array,
                default() {
                    return []
                }
            },
            api: {
                type: String
            },
            exportData: {
                type: Boolean,
                default: true
            },
            showSummary: {
                type: Boolean,
                default: false
            },
            summaryKill: {
                type: Array,
                default() {
                    return []
                }
            },
            summaryInt: {
                type: Array,
                default() {
                    return []
                }
            },
            searchData: {
                type: Object,
                default: {}
            },
            isShowData: {
                type: Boolean,
                default: false
            },
            hide0: { // 是否控制全为0不显示
                type: Boolean,
                default: false
            },
            hidePam: { // 需要控制的参数数组
                type: Array,
                default() {
                    return []
                }
            },
        },
        data() {
            return {
                isTableLoading: false,
                mainList: {
                    name: 'getMainList',
                    page: 1,
                    pageSize: 10,
                    total: 0,
                },
                mainTable: [],
                mainTableSelList: [],
            }
        },
        computed: {},
        methods: {
            changePage: function (obj, page) {
                obj.page = page
                this[obj.name](this.searchData)
            },

            changePageSize: function (obj, pageSize) {
                obj.pageSize = pageSize
                this[obj.name](this.searchData)
            },

            // 查询按钮
            query: function () {
                this.mainList.page = 1
                this.$emit('on-query')
            },

            // 重置
            refresh: function () {
                this.$emit('on-refresh')
            },

            // 导出
            handleExport: function() {
                this.$emit('on-export')
            },

            // 获取主表
            getMainList: function (data = {}, cb) {
                let vm = this
                vm.mainTable = []
                vm.isTableLoading = true
                $http(vm.$api[vm.api], data, (res) => {
                    vm.mainList.total = parseInt(res.total)
                    if(vm.hide0) {
                        vm.cnmHide(res.data)
                    } else {
                        vm.mainTable = res.data || []
                    }
                    vm.isTableLoading = false
                    cb && cb(res)
                }, vm.mainList, (err) => {
                    console.log(err)
                    vm.isTableLoading = false
                })
            },

            // 操作数据
            cnmHide: function(list = []) {
                list.forEach(item => {
                    let isHide = this.hidePam.every(pam => {
                        return item[pam] == 0
                    })
                    if(isHide) {
                        this.hidePam.map(p => {
                            item[p] = ''
                        })
                    }
                })
                this.mainTable = list
            },

            /**
             *  选中要导出的数据
             * @param select
             */
            handleSelect: function (select) {
                this.mainTableSelList = select
            },
        },
        created: function () {},
        mounted: function () {}
    }
</script>

<style scoped>

</style>
