import ProductSelect from './product-select.vue'
export default ProductSelect
