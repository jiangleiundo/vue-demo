<template>
  <Select
    ref="ProductSelect"
    :value="curVal"
    @on-change="handleChange"
    :placeholder="placeholder"
    :class="clz"
    :clearable="curClr"
    :disabled="currentDisabled"
    :label-in-value="valueShows"
    :multiple='multiple'
    transfer
    :max-tag-count='maxTagCount'
  >
    <Option v-if="showAll" value>全部</Option>
    <Option
      v-for="product in products"
      :value="product.productId"
      :label="product.productName"
      :key="`product-col-${product.productId}`"
    >
      <Poptip trigger="hover" placement="right" transfer :disabled='disabledPop'>
        <a>{{ product.productName }}</a>
        <Card slot="content" class="product-card">
          <Row>
            <Col span="12">
              <span class="product-span">
                <b>业务模式：</b>
                {{ product.modeName }}
              </span>
            </Col>
            <Col span="12">
              <span class="product-span">
                <b>违约金计收标准：</b>
                {{valueToText(product.penalSumRate, 'thousandRate')}}
              </span>
            </Col>
          </Row>
          <Row>
            <Col span="12">
              <span class="product-span">
                <b>利率：</b>
                {{valueToText(product.rate, 'rate')}}
              </span>
            </Col>
            <Col span="12">
              <span class="product-span">
                <b>展期利率倍数：</b>
                {{valueToText(product.penaltyRate, 'rate')}}
              </span>
            </Col>
          </Row>
          <Row>
            <Col span="12">
              <span class="product-span">
                <b>保理费率：</b>
                {{valueToText(product.factoringRate, 'rate')}}
              </span>
            </Col>
            <Col span="12">
              <span class="product-span">
                <b>最低保理费金额：</b>
                {{valueToText(product.minFactoringAmt, 'money')}}
              </span>
            </Col>
          </Row>
          <Row>
            <Col span="12">
              <span class="product-span">
                <b>产品期限(月)：</b>
                {{ product.productLimit }}
              </span>
            </Col>
            <Col span="12">
              <span class="product-span">
                <b>宽限期(天)：</b>
                {{ product.productGraceLimit }}
              </span>
            </Col>
          </Row>
          <Row>
            <Col span="12">
              <span class="product-span">
                <b>违约判断天数：</b>
                {{ product.penaltyJudgeDays }}
              </span>
            </Col>
            <Col span="12">
              <span class="product-span">
                <b>是否允许提前还款：</b>
                {{valueToText(product.allowPrepayment, 'dict', 'YES_NO')}}
              </span>
            </Col>
          </Row>
          <Row>
            <Col span="12">
              <span class="product-span">
                <b>还款方式：</b>
                {{ buildRepayType(product) }}
              </span>
            </Col>
          </Row>
        </Card>
      </Poptip>
    </Option>
  </Select>
</template>

<script>
import { Select, Option, Row, Col, Poptip, Card } from "view-design";
import { ApiUtils } from "multi-tenant-common";

export default {
  name: "ProductSelect",
  components: {
    Select,
    Option,
    Row,
    Col,
    Poptip,
    Card
  },
  model: {
    prop: "value",
    event: "change"
  },
  props: {
    value: {
      type: [String, Number],
      default: ""
    },
    split: {
      type: String,
      default: ","
    },
    placeholder: {
      type: String
    },
    clz: {
      type: String
    },
    disabled: {
      type: Boolean,
      default: false
    },
    clearable: {
      type: Boolean,
      default: false
    },
    showAll: {
      type: Boolean,
      default: false
    },
    multiple: {
      type: Boolean,
      default: false
    },
    valueShow: {
      type: Boolean,
      default: false
    },
    disabledPoptip: {
      type: Boolean,
      default: false
    },
    maxTagCount: {
      type: [String,Number],
      default: 1
    },
  },
  computed: {},
  data() {
    return {
      valueToText: ApiUtils.valueToText,
      products: [],
      currentDisabled: this.disabled,
      disabledPop: this.disabledPoptip,
      curClr: this.clearable,
      valueShows: this.valueShow,
      curVal: typeof this.value === "object" ? this.value : this.value + "",
      sign:  this.valueShow? 1:''
    };
  },
  watch: {
    value(val) {
      this.curVal = typeof val === "object" ? val : val + "";
    },
    disabled(val) {
      this.currentDisabled = val;
    },
    clearable(val) {
      this.curClr = val;
    },
    disabled(val) {
      this.currentDisabled = val;
    }
  },
  methods: {
    buildRepayType(product) {
      let msg = "";
      if (product && product.repayType) {
        if (product.repayType == "0") {
          msg = "利随本清";
        } else if (product.repayType == "1") {
          msg = "按月付息到期还款";
        } else if (product.repayType == "2") {
          msg = "按季付息到期还款";
        } else if (product.repayType == "3") {
          msg = "到期前" + product.beforeNNo + "月回款就扣";
        }
      }
      return msg;
    },
    handleChange(selected) {
      if (this.valueShow) {
        this.curVal = selected.value;
        this.$emit("on-change-name", selected.label);
      } else {
        this.curVal = selected;
      }
      this.$emit("change", this.curVal);
      this.$emit("on-change", this.curVal);

    },
    queryProducts() {
      var vm = this;
      vm.$request({
        url: "/api/v1/biz/biz-product/query-eff-product-list-for-seller",
        data: {
            sellerId:vm.$store.state.user.user.seller.sellerId,
            sign:vm.sign
        },
        success: res => {
          vm.products = res.data;
          if (vm.products && vm.products.length > 0) {
            vm.products.forEach(item => {
              item.productId = item.productId + "";
            });
          }
        }
      });
    }
  },
  created() {
    this.queryProducts();
  }
};
</script>

<style>
.product-checkbox {
  height: 40px;
  line-height: 2.5;
}

.product-card {
  width: 350px;
}

.product-span {
  margin-right: 10px;
}
</style>
