<template>
    <div>
        <div v-if="!btnShow" v-for="file in fileList" class="files-upload-list">
            <div v-if="file.fileId" style="height: 100px">
                <img v-if="fileUploadUtil.isImg(file)" :src="file.url">
                <img v-if="fileUploadUtil.isPdf(file)" src="./pdf.jpg">
<!--                <iframe v-if="fileUploadUtil.isPdf(file)" :src="file.url" class="files-pdf-view"></iframe>-->
                <div v-if="!fileUploadUtil.isImg(file) && !fileUploadUtil.isPdf(file)">
                    <span>{{file.name}}</span>
                </div>
                <div v-if="file.fileId" class="files-upload-list-cover">
                    <Icon v-if="!fileUploadUtil.isOther(file)" type="ios-eye-outline"
                          @click.native="handleView(file)"></Icon>
                    <Icon type="md-arrow-down" @click.native="handleDownload(file)"></Icon>
                    <Icon v-if="!viewFlag" type="ios-trash-outline" @click.native="handleRemove(file)"></Icon>
                </div>
            </div>
            <Progress v-if="file.showProgress" :percent="file.percentage" status="active" :stroke-width="20"
                      text-inside></Progress>
        </div>
        <div v-if="btnShow && value">
            <Button type="text" @click="handleTradeView"><Icon custom="iconfont icon-view" size="18"></Icon></Button>
        </div>
        <Upload v-show="!viewFlag && fileList.length < maxCount"
                ref="upload"
                :name="name"
                :format="format"
                :show-upload-list="false"
                :max-size="20480"
                :on-success="handleSuccess"
                :on-format-error="handleFormatError"
                :on-exceeded-size="handleMaxSize"
                :before-upload="handleBeforeUpload"
                multiple
                type="drag"
                :action="fileUploadUtil.FILE_UPLOAD_URL"
                style="display: inline-block;width:98px;">
            <div style="width: 98px;height:98px;line-height: 98px;">
                <Icon type="ios-camera" size="30"></Icon>
            </div>
        </Upload>
        <ImgView v-model="imgViewShow" :fileId="file.fileId" @on-cancel="imgViewShow = false"
                 :fullscreen="fullscreen"></ImgView>
        <PdfView v-model="pdfViewShow" :fileId="file.fileId" @on-cancel="pdfViewShow = false"
                 :fullscreen="fullscreen"></PdfView>
    </div>
</template>
<script>
    import {Upload, Icon, Modal, Button} from 'view-design';
    import {request, arrayToStr, strToArray, warnM} from '../../libs/api.utils'
    import fileUploadUtil from './upload'
    import ImgView from '../img-view'
    import PdfView from '../pdf-view'
    import Emitter from '../../mixins/emitter';

    export default {
        name: 'FilesUpload',
        mixins: [Emitter],
        components: {
            Upload, Icon, Modal, ImgView, PdfView, Button
        },
        model: {
            prop: 'value',
            event: 'change'
        },
        props: {
            value: {
                type: [String, Number, Array],
                default: () => {
                    return []
                }
            },
            /**
             * value数据类型：
             * fileList：文件列表，默认，示例：[{file1},{file2}]
             * fileId：文件ID，示例：123
             * fileIds：文件ID列表，数组或者逗号分隔的文件ID字符串，需配合fileType使用
             * trade：根据交易ID获取交易类型，示例：[tradeId,type]
             */
            type: {
                type: String,
                default: 'fileList'
            },
            tradeType: {
                type: String
            },
            fileName: {
                type: String,
                default: '文件'
            },
            fileType: {
                type: String,
                default: '.pdf'
            },
            name: {
                type: String,
                default: 'file'
            },
            viewFlag: {
                type: Boolean,
                default: false
            },
            maxCount: { // 最大文件限制
                type: Number,
                default: 99
            },
            fullscreen: {
                type: Boolean,
                default: false
            },
            format: {
                type: Array,
                default: () => {
                    return []
                }
            },
        },
        data() {
            return {
                fileUploadUtil: fileUploadUtil,
                fileList: [],
                imgName: '',
                imgViewShow: false,
                pdfViewShow: false,
                file: {},
            }
        },
        watch: {
            value(val) {
                this.changeValue(val)
            }
        },
        computed: {
            btnShow() {
                return this.type == 'trade' || this.type == 'fileId'
            }
        },
        methods: {
            changeValue(val) {
                if (this.viewFlag) {
                    this.fileList = this.buildDefaultFileList(val)
                } else {
                    this.fileList = this.$refs.upload.fileList = this.buildFileList(val)
                }
            },
            buildDefaultFileList(val) {
                val = val || this.value
                let vm = this
                let fileList = []
                if (vm.type) {
                    if (vm.type == 'fileIds') {
                        if (val) {
                            let fileIds = typeof val === 'object' ? val : strToArray(val+'')
                            if (fileIds && fileIds.length > 0) {
                                fileList = fileIds.map(item => {
                                    return fileUploadUtil.buildFile({
                                        fileName: vm.fileName,
                                        fileType: vm.fileType,
                                        fileId: item
                                    })
                                })
                            }
                        }
                    } else if (vm.type == 'fileIdList') {
                        if (val && val.length > 0) {
                            fileList = val.map(item => {
                                return fileUploadUtil.buildFile({
                                    fileName: vm.fileName,
                                    fileType: vm.fileType,
                                    fileId: item
                                })
                            })
                        }
                    } else if (vm.type == 'url') {
                        if (val) {
                            fileList = [{
                                name: vm.fileName,
                                url: val,
                                fileType: vm.fileType
                            }]
                        }
                    } else {
                        fileList = vm.buildFileList(val);
                    }
                } else {
                    fileList = vm.buildFileList(val);
                }
                return fileList
            },
            buildFileList(fileList) {
                if (fileList &&  Array.isArray(fileList) && fileList.length > 0) {
                    return fileList.map(item => {
                        return fileUploadUtil.buildFile(item)
                    })
                } else {
                    return []
                }
            },
            handleTradeView() {
                let vm = this
                if(vm.type == 'trade') {
                    request({
                        url: '/api/v1/file-mgr/query-file-list',
                        data: {
                            businessType: vm.tradeType,
                            businessId: vm.value
                        },
                        success: res => {
                            if(res.data && res.data.length > 0) vm.handleView(res.data[0])
                        }
                    })
                } else if(vm.type == 'fileId') {
                    request({
                        url: '/api/v1/file-mgr/query-file-by-id',
                        data: {
                            fileId: vm.value
                        },
                        success: res => {
                            if(res.data) vm.handleView(res.data)
                        }
                    })
                }
            },
            handleView(file) {
                this.file = file;
                if (this.fileUploadUtil.isImg(file)) {
                    this.imgViewShow = true
                } else if (this.fileUploadUtil.isPdf(file)) {
                    this.pdfViewShow = true
                }
            },
            handleDownload(file) {
                let url = this.fileUploadUtil.FILE_DOWNLOAD_URL + file.fileId;
                window.location.href = url;
            },
            buildReturnFiles() {
                return this.fileList.map(item => {
                    return {
                        fileId: item.fileId,
                        fileName: item.fileName,
                        fileSize: item.fileSize,
                        fileType: item.fileType
                    }
                })
            },
            handleRemove(file) {
                let vm = this
                // request({
                //     url: fileUploadUtil.FILE_REMOVE_URL + file.fileId,
                //     data: {},
                //     success: res => {
                vm.fileList.splice(vm.fileList.indexOf(file), 1)
                vm.$emit('on-change', vm.buildReturnFiles())
                vm.$emit('change', vm.buildReturnFiles())
                vm.dispatch('FormItem', 'on-form-change', vm.buildReturnFiles());
                //     }
                // })
            },
            handleSuccess(res, file) {
                let f = fileUploadUtil.buildFile(res.data)
                if (f) {
                    Object.assign(file, f)
                    this.$set(this, 'fileList', this.fileList)
                    this.$emit('on-change', this.buildReturnFiles())
                    this.$emit('change', this.buildReturnFiles())
                    this.dispatch('FormItem', 'on-form-change', this.buildReturnFiles());
                }
            },
            handleFormatError(file) {
                let msg = '上传文件格式错误'
                if(this.format && this.format.length > 0) {
                    msg += '，仅支持以下文件格式：' + arrayToStr(this.format)
                }
                warnM(msg)
            },
            handleMaxSize(file) {
                warnM('上传文件大小超过最大上传限制20MB！')
            },
            handleBeforeUpload() {
                const check = this.fileList.length < this.maxCount;
                if (!check) {
                    warnM('上传文件数超过最大上传限制数：' + this.maxCount)
                }
                return check;
            },
        },
        mounted() {
            this.changeValue(this.value)
        }
    }
</script>
<style scoped>
    .files-upload-list {
        display: inline-block;
        width: 100px;
        height: 100px;
        text-align: center;
        line-height: 100px;
        border: 1px solid transparent;
        border-radius: 4px;
        overflow: hidden;
        background: #fff;
        position: relative;
        box-shadow: 0 1px 1px rgba(0, 0, 0, .2);
        margin-right: 4px;
    }

    .files-upload-list img {
        width: 100%;
        height: 100%;
    }

    .files-upload-list Progress {
        width: 90%;
    }

    .files-upload-list-cover {
        display: none;
        position: absolute;
        top: 0;
        bottom: 0;
        left: 0;
        right: 0;
        background: rgba(0, 0, 0, .6);
    }

    .files-upload-list:hover .files-upload-list-cover {
        display: block;
    }

    .files-upload-list-cover i {
        color: #fff;
        font-size: 20px;
        cursor: pointer;
        margin: 0 2px;
    }

    .files-pdf-view {
        width: 100%;
        height: 100px;
        text-align: center;
    }

    .fu-trade-btn {
        border: none;
        backgroundColor: inherit;
        width: 35px;
        textAlign: center;
    }
</style>
