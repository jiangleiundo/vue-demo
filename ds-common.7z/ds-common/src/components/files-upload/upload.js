const fileUploadUtil = {
    IMG_TYPES: new Set(['.bmp', '.jpg', '.jpeg', '.png', '.tif', '.gif']),
    PDF_TYPE: '.pdf',
    FILE_UPLOAD_URL: '/api/v1/file-mgr/upload',
    FILE_DOWNLOAD_URL: '/api/v1/file-mgr/download?fileId=',
    FILE_REMOVE_URL: '/api/v1/file-mgr/remove?fileId=',
    IMG_VIEW_URL: '/api/v1/file-mgr/img-view?fileId=',
    PDF_VIEW_URL: '/api/v1/file-mgr/pdf-view?fileId=',
    isImg: file => {
        return file && file.fileType && fileUploadUtil.IMG_TYPES.has(file.fileType)
    },
    isPdf: file => {
        return file && file.fileType && fileUploadUtil.PDF_TYPE == file.fileType
    },
    isOther: file => {
        return !(fileUploadUtil.isImg(file) || fileUploadUtil.isPdf(file))
    },
    buildFile: file => {
        if(file) {
            if(file.fileType) {
                if(fileUploadUtil.IMG_TYPES.has(file.fileType)) { // 图片
                    file.url = fileUploadUtil.IMG_VIEW_URL + file.fileId
                } else if(fileUploadUtil.PDF_TYPE == file.fileType) { // PDF
                    file.url = fileUploadUtil.PDF_VIEW_URL + file.fileId
                } else { // 其他

                }
            }
            if(file.fileName) {
                file.name = file.fileName
            } else {
                file.name = '文件-' + file.fileId
            }
        }
        return file
    }
}

export default fileUploadUtil
