import FilesUpload from './files-upload.vue'
export default FilesUpload
