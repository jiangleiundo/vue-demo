<template>
    <div>
        <Tag v-for="dict in dicts" :key="`dict-tag-${dict.dictId}`" :name="dict.value" @on-click="handleClick(dict)">
            {{ dict.name }}
        </Tag>
    </div>
</template>

<script>
    import Tag from '../tag';
    import {getDicts} from '../../libs/api.utils'

    export default {
        name: 'DictTag',
        components: {
            Tag
        },
        model: {
            prop: 'value',
            event: 'change'
        },
        props: {
            value: {
                type: [String, Number]
            },
            code: {
                type: String,
                required: true
            },
            clz: {
                type: String
            },
            disabled: {
                type: Boolean,
                default: false
            },
            filter: {
                type: Array
            },
            filterKill: {
                type: Array
            }
        },
        computed: {},
        data() {
            return {
                dicts: this.getDicts(),
                currentDisabled: this.disabled
            }
        },
        watch: {
            disabled(val) {
                this.currentDisabled = val
            },
            filter(val) {
                this.filter = val
                this.dicts = this.getDicts()
            },
            filterKill(val) {
                this.filterKill = val
                this.dicts = this.getDicts()
            },
            code(val) {
                this.code = val
                this.dicts = this.getDicts()
            }
        },
        methods: {
            getDicts() {
                return getDicts(this.code, this.filter, this.filterKill)
            },
            handleClick(selected) {
                this.$emit('change', selected)
                this.$emit('on-change', selected)
            }
        }
    }
</script>

<style>
    .dict-radio {
        height: 40px;
        line-height: 2.5;
    }
</style>
