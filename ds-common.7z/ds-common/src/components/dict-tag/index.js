import DictTag from './dict-tag.vue'
export default DictTag
