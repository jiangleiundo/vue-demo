<template>
    <div :class="wrapClasses">
        <div :class="inputWrapClasses">
            <input
                :id="elementId"
                :class="inputClasses"
                :disabled="itemDisabled"
                autocomplete="off"
                spellcheck="false"
                :autofocus="autofocus"
                @focus="focus"
                @blur="blur"
                @input="change"
                @mouseup="preventDefault"
                @change="change"
                :readonly="readonly || !editable"
                :name="name"
                :value="formatterValue"
                :placeholder="placeholder">
        </div>
        <div class="ivu-input-group-append" v-if="append" v-show="slotReady"><slot name="append"></slot></div>
    </div>
</template>
<script>
    import {oneOf, findComponentUpward} from '../../libs/util';
    import Emitter from '../../mixins/emitter';
    import math from 'mathjs'
    import mixinsForm from '../../mixins/form';

    const prefixCls = 'ivu-input-number';
    const iconPrefixCls = 'ivu-icon';

    function addNum(num1, num2) {
//        let sq1, sq2, m;
//        try {
//            sq1 = num1.toString().split('.')[1].length;
//        }
//        catch (e) {
//            sq1 = 0;
//        }
//        try {
//            sq2 = num2.toString().split('.')[1].length;
//        }
//        catch (e) {
//            sq2 = 0;
//        }
//        if (sq1 === 0 || sq2 === 0) {
//            return num1 + num2;
//        } else {
//            m = Math.pow(10, Math.max(sq1, sq2));
//            return (num1 * m + num2 * m) / m;
//        }
//        m = Math.pow(10, Math.max(sq1, sq2));
//        return (Math.round(num1 * m) + Math.round(num2 * m)) / m;
        if (!num1) {
            num1 = 0
        }
        // math.add(math.bignumber(num1), num2) 是个对象
        return math.add(math.bignumber(num1), num2).d[0] + ''
    }

    export default {
        name: 'InputNumber',
        mixins: [Emitter, mixinsForm],
        props: {
            max: {
                type: [String, Number],
                default: '999999999999999999'
            },
            min: {
                type: [String, Number],
                default: '-999999999999999999'
            },
            step: {
                type: Number,
                default: 1
            },
            activeChange: {
                type: Boolean,
                default: false
            },
            value: {
                type: [String, Number]
            },
            size: {
                validator(value) {
                    return oneOf(value, ['small', 'large', 'default']);
                },
                default() {
                    return !this.$IVIEW || this.$IVIEW.size === '' ? 'default' : this.$IVIEW.size;
                }
            },
            disabled: {
                type: Boolean,
                default: false
            },
            autofocus: {
                type: Boolean,
                default: false
            },
            readonly: {
                type: Boolean,
                default: false
            },
            editable: {
                type: Boolean,
                default: true
            },
            name: {
                type: String
            },
            precision: {
                type: Number
            },
            elementId: {
                type: String
            },
            formatter: {
                type: Function
            },
            parser: {
                type: Function
            },
            placeholder: {
                type: String,
                default: ''
            },
        },
        data() {
            return {
                slotReady: false,
                focused: false,
                upDisabled: false,
                downDisabled: false,
                currentValue: this.value
            };
        },
        computed: {
            wrapClasses() {
                return [
                    `${prefixCls}`,
                    {
                        [`${prefixCls}-${this.size}`]: !!this.size,
                        [`${prefixCls}-disabled`]: this.itemDisabled,
                        [`${prefixCls}-focused`]: this.focused,
                        'ivu-input-group-with-append': this.append,
                    }
                ];
            },
            handlerClasses() {
                return `${prefixCls}-handler-wrap`;
            },
            upClasses() {
                return [
                    `${prefixCls}-handler`,
                    `${prefixCls}-handler-up`,
                    {
                        [`${prefixCls}-handler-up-disabled`]: this.upDisabled
                    }
                ];
            },
            innerUpClasses() {
                return `${prefixCls}-handler-up-inner ${iconPrefixCls} ${iconPrefixCls}-ios-arrow-up`;
            },
            downClasses() {
                return [
                    `${prefixCls}-handler`,
                    `${prefixCls}-handler-down`,
                    {
                        [`${prefixCls}-handler-down-disabled`]: this.downDisabled
                    }
                ];
            },
            innerDownClasses() {
                return `${prefixCls}-handler-down-inner ${iconPrefixCls} ${iconPrefixCls}-ios-arrow-down`;
            },
            inputWrapClasses() {
                return `${prefixCls}-input-wrap`;
            },
            inputClasses() {
                return `${prefixCls}-input`;
            },
            precisionValue() {
                // can not display 1.0
                if (!this.currentValue) return this.currentValue;
                let num = this.currentValue + ''
                let p = num.split('.')
                if (!isNaN(this.precision) && p[1] && p[1].length > this.precision) {
                    num = math.bignumber(this.currentValue).toFixed(this.precision)
                    // p[1] = p[1].substring(0, this.precision)
                    // num = p.join('.')
                }
                if (math.bignumber(num).cmp(math.bignumber(this.max)) >= 0) {
                    num = this.max;
                } else if (math.bignumber(num).cmp(math.bignumber(this.min)) <= 0) {
                    num = this.min;
                }
                return this.precision ? num : this.currentValue;
            },
            formatterValue() {
                if (this.formatter && this.precisionValue !== null) {
                    return this.formatter(this.precisionValue);
                } else {
                    return this.precisionValue;
                }
            },
            append () {
                return this.$slots.append !== undefined;
            }
        },
        methods: {
            preventDefault(e) {
                e.preventDefault();
            },
            up(e) {
                const targetVal = e.target.value
                if (this.upDisabled && isNaN(targetVal)) {
                    return false;
                }
                this.changeStep('up', e);
            },
            down(e) {
                const targetVal = e.target.value;
                if (this.downDisabled && isNaN(targetVal)) {
                    return false;
                }
                this.changeStep('down', e);
            },
            changeStep(type, e) {
                if (this.itemDisabled || this.readonly) {
                    return false;
                }

                const targetVal = e.target.value
                let val = this.currentValue
                const step = this.step
                if (isNaN(val)) {
                    return false;
                }

                // input a number, and key up or down
                if (!isNaN(targetVal)) {
                    if (type === 'up') {
                        if (addNum(targetVal, step) <= this.max) {
                            val = targetVal;
                        } else {
                            return false;
                        }
                    } else if (type === 'down') {
                        if (addNum(targetVal, -step) >= this.min) {
                            val = targetVal;
                        } else {
                            return false;
                        }
                    }
                }

                if (type === 'up') {
                    val = addNum(val, step);
                } else if (type === 'down') {
                    val = addNum(val, -step);
                }
                this.setValue(val);
            },
            setValue(val) {
                // 如果 step 是小数，且没有设置 precision，是有问题的
                if (val) {
                    let p = (val + '').split('.')
                    if(this.precision == 0) {
                        val = p[0]
                    } else if (!isNaN(this.precision) && p[1] && p[1].length > this.precision) {
                        val = math.bignumber(val).toFixed(this.precision)
                        // p[1] = p[1].substring(0, this.precision)
                        // val = p.join('.')
                    }
                }
                const {min, max} = this;
                if (val !== null) {
                    if (math.bignumber(val).cmp(math.bignumber(max)) >= 0) {
                        val = max;
                    } else if (math.bignumber(val).cmp(math.bignumber(min)) <= 0) {
                        val = min;
                    }
                }
                this.$nextTick(() => {
                    this.currentValue = val;
                    this.$emit('input', val);
                    this.$emit('on-change', val);
                    this.dispatch('FormItem', 'on-form-change', val);
                });
            },
            focus(event) {
                this.focused = true;
                this.$emit('on-focus', event);
            },
            blur(event) {
                this.focused = false;
                this.$emit('on-blur', event);
                if (!findComponentUpward(this, ['DatePicker', 'TimePicker', 'Cascader', 'Search'])) {
                    this.dispatch('FormItem', 'on-form-blur', this.currentValue);
                }
            },
            keyDown(e) {
                if (e.keyCode === 38) {
                    e.preventDefault();
                } else if (e.keyCode === 40) {
                    e.preventDefault();
                }
            },
            change(event) {
                if (event.type == 'input' && !this.activeChange) return;
                let val = event.target.value.trim();

                if (event.type == 'input' && val.match && val.match(/^\-?\.?$|\.$/)) return;

                if (this.parser) {
                    val = this.parser(val);
                }

                const isEmptyString = val.length === 0;
                if (isEmptyString) {
                    this.setValue(null);
                    return;
                }

                // val = Number(val);
                if (!isNaN(val)) {
                    this.currentValue = val;
                    this.setValue(val);
                } else {
                    event.target.value = this.currentValue;
                }
            },
            changeVal(val) {
//                val = Number(val);
                if (!isNaN(val)) {
                    const step = this.step;

                    this.upDisabled = val + step >= this.max;
                    this.downDisabled = val - step <= this.min;
                } else {
                    this.upDisabled = true;
                    this.downDisabled = true;
                }
            }
        },
        mounted() {
            // this.changeVal(this.currentValue);
            this.slotReady = true
        },
        watch: {
            value(val) {
                this.currentValue = val;
            },
            // currentValue(val) {
            //     this.changeVal(val);
            // },
            // min() {
            //     this.changeVal(this.currentValue);
            // },
            // max() {
            //     this.changeVal(this.currentValue);
            // }
        }
    };
</script>
