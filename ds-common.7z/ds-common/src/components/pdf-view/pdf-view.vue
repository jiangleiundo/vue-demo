<template>
    <Modal :z-index="9999" :title="title" v-model="pdfShow" @on-cancel="handleCancel" :width="fullscreen ? 100 : 60"
           :fullscreen="fullscreen" transfer>
        <iframe v-if="pdfShow" :src="curUrl"
                :style="{width: '100%',height: fullscreen ? '100%' : '750px',border: 'medium none'}"></iframe>
        <slot></slot>
        <div slot="footer">
        </div>
    </Modal>
</template>
<script>
    import fileUploadUtil from '../files-upload/upload'

    export default {
        components: {},
        name: 'PdfView',
        props: {
            value: {
                type: Boolean,
                default: false
            },
            fileId: {
                type: [Number, String]
            },
            title: {
                type: String,
                default: '查看'
            },
            url: {
                type: String
            },
            fullscreen: {
                type: Boolean,
                default: false
            }
        },
        data() {
            return {
                pdfShow: this.value,
                curUrl: this.url || fileUploadUtil.PDF_VIEW_URL + this.fileId,
            }
        },
        watch: {
            value(val) {
                this.pdfShow = val
            },
            fileId(val) {
                this.curUrl = fileUploadUtil.PDF_VIEW_URL + this.fileId
            },
            url(val) {
                this.curUrl = val
            }
        },
        methods: {
            handleCancel(e) {
                this.pdfShow = false
                this.$emit('update:value', false)
                this.$emit('on-cancel')
            }
        },
        mounted() {
        }
    }
</script>
<style lang="less" scoped>

</style>
