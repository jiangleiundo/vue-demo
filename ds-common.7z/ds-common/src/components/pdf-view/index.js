import PdfView from './pdf-view.vue'
export default PdfView
