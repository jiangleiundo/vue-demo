<template>
    <div>
        <Row>标题</Row>
        <Row>
            <Col span="3" v-for="(week, index) in weeks">
                <Table :columns="getColumns(index)"></Table>
            </Col>
        </Row>
    </div>
</template>

<script>
    import {getWeekDate} from '../../libs/api.utils'

    export default {
        name: 'WeekCalendar',
        model: {
            prop: 'value',
            event: 'change'
        },
        props: {
            value: {
                type: Number
            },
            placeholder: {
                type: String
            },
            clz: {
                type: String
            },
            days: {
                type: Array,
                default: () => {
                    return getWeekDate()
                }
            },
        },
        computed: {},
        data() {
            return {
                weeks: ['星期一', '星期二', '星期三', '星期四', '星期五', '星期六', '星期日'],
                currentDays: this.days
            }
        },
        watch: {},
        methods: {
            getColumns(i) {
                let columns = [{
                    title: this.weeks[i] + '<br/>(' + this.currentDays[i] + ')',
                    align: 'center',
                    key: 'data',
                    renderHeader
                }]
                return columns
            }
        }
    }
</script>

<style>

</style>
