import WeekCalendar from './week-calendar.vue'
export default WeekCalendar
