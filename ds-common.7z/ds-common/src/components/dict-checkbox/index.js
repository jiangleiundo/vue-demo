import DictCheckbox from './dict-checkbox.vue'
export default DictCheckbox
