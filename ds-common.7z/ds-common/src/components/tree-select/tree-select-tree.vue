<template>
    <Tree
        :data="data"
        @on-check-change="handleCheckSelect"
        @on-select-change="handleSelect"
        v-on="parent.$listeners"
        v-bind="parent.$attrs"
        :load-data="loadDataCallback"
        :show-checkbox="multiple"
        :check-strictly="false"
        :check-directly="false"
    ></Tree>
</template>

<script>
    import {Tree} from 'view-design';
    import Emitter from '../../mixins/emitter';

    const arrayEqual = (arr1, arr2) => {
        // 判断数组的长度
        if (arr1.length !== arr2.length) {
            return false
        } else {
            // 循环遍历数组的值进行比较
            for (let i = 0; i < arr1.length; i++) {
                if (arr1[i] !== arr2[i]) {
                    return false
                }
            }
            return true
        }
    }

    export default {
        name: 'TreeSelectTree',
        components: {
            Tree
        },
        mixins: [Emitter],
        props: {
            data: {
                type: Array,
                default: () => []
            },
            selectedArray: {
                type: Array,
                default: () => []
            },
            selectedData: {
                type: [String, Number]
            },
            loadData: Function
        },
        data() {
            return {
                flatDic: {},
                checkedArray: []
            }
        },
        inject: ['parent'],
        computed: {
            expandAll () {
                return this.parent.$attrs['expand-all']
            },
            multiple() {
                return this.parent.multiple
            }
        },
        watch: {
            data (newData, oldVal) {
                if(this.multiple) {
                    this.updateFlagDic(newData)
                    let selectArray = []
                    this.selectedArray.forEach(id => {
                        if (id in this.flatDic) selectArray.push(id)
                    })
                    this.$emit('on-check', selectArray.map(id => this.flatDic[id]))
                    if (this.expandAll) this.checkData(newData, false, true)
                } else {
                    if (this.expandAll) this.checkData(newData, false, true)
                }
            },
            selectedArray (newVal, oldVal) {
                if (arrayEqual(newVal, oldVal)) return
                const filtedNewVal = newVal.filter(id => id in this.flatDic)
                this.$emit('on-check', filtedNewVal.map(id => this.flatDic[id]))
                this.$emit('on-clear')
                this.$nextTick(() => {
                    this.checkData(this.data, true)
                })
            },
            selectedData (newVal, oldVal) {
                if (newVal == oldVal) return
                this.$emit('on-select', newVal)
                this.$emit('on-clear')
                this.$nextTick(() => {
                    this.checkData(this.data, true)
                })
            }
        },
        methods: {
            checkEmit (value, label) {
                this.dispatch('iSelect', 'on-select-selected', {
                    value,
                    label
                })
                this.$emit('on-select-selected', {
                    value,
                    label
                })
            },
            updateFlagDic (newData) {
                let newFlagDic = {}
                this.setFlagDic(newData, item => {
                    newFlagDic[item.id] = item
                })
                this.flatDic = newFlagDic
            },
            setFlagDic (data, callback) {
                data.forEach(item => {
                    if (item.children && item.children.length) {
                        this.setFlagDic(item.children, callback)
                    }
                    callback(item)
                })
            },
            handleCheckSelect (selectArray, selectItem) {
                if(this.multiple) {
                    this.$emit('on-check', selectArray)
                    // this.parent.$emit('on-change', selectArray)
                }
            },
            handleSelect (selectArray, selectItem) {
                if(!this.multiple) {
                    this.$emit('on-select', selectItem.id)
                    // this.parent.$emit('on-change', selectItem.id)
                }
            },
            checkData (data, emit, expandAll) {
                if(this.multiple) {
                    let parentIdSet = new Set()
                    data.forEach(item => {
                        if (this.selectedArray.includes(item.id) && item.parentId) {
                            parentIdSet.add(item.parentId+'')
                        }
                    })
                    data.forEach(item => {
                        if (this.selectedArray.includes(item.id) && !(item.children && item.children.length)) {
                            this.$set(item, 'checked', true)
                            this.checkedArray.push(item)
                            if (emit) this.checkEmit(item.id, item.title)
                        }
                        if (item.children && item.children.length) {
                            if ((this.expandAll && expandAll) || parentIdSet.has(item.id+'')) this.$set(item, 'expand', true)
                            this.checkData(item.children, emit, expandAll)
                        }
                    })
                } else {
                    let parentId = ''
                    data.forEach(item => {
                        if (this.selectedData == item.id && item.parentId) {
                            parentId = item.parentId
                        }
                    })
                    data.forEach(item => {
                        if (this.selectedData == item.id) {
                            this.$set(item, 'selected', true)
                            this.$emit('on-select', item.id)
                            if (emit) this.checkEmit(item.id, item.title)
                        } else this.$set(item, 'selected', false)
                        if (item.children && item.children.length) {
                            if ((this.expandAll && expandAll) || parentId == item.id) this.$set(item, 'expand', true)
                            this.checkData(item.children, emit, expandAll)
                        }
                    })
                }
            },
            loadDataCallback (item, callback) {
                this.loadData(item, data => {
                    return (() => {
                        callback(data)
                        this.multiple && this.updateFlagDic(this.data)
                    })(data)
                })
            }
        },
        mounted () {
            this.checkData(this.data, false, true)
            this.$nextTick(() => {
                if(this.multiple) {
                    this.$emit('on-check', this.checkedArray)
                } else {
                    this.$emit('on-select', this.checkedData)
                }
            })
        }
    }
</script>

<style></style>
