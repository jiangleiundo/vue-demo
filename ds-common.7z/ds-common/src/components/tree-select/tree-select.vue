<template>
    <Select
        ref="select"
        :placeholder="placeholder"
        class="tree-select"
        :class="clz"
        v-bind="$attrs"
        @on-change="handleChange"
        :multiple="multiple"
        :clearable="clearable"
        :max-tag-count="maxTagCount"
        transfer
    >
        <tree-select-tree-item
            :selectedData="selectedData"
            :selectedArray="selectedArray"
            :data="treeData"
            @on-clear="handleClear"
            :load-data="loadData"
            @on-check="handleTreeCheck"
            @on-select="handleTreeSelect"
        ></tree-select-tree-item>
    </Select>
</template>

<script>
    import {Select} from 'view-design';
    import Emitter from '../../mixins/emitter';
    import TreeSelectTreeItem from './tree-select-tree.vue'

    export default {
        name: 'TreeSelect',
        mixins: [Emitter],
        components: {
            Select,
            TreeSelectTreeItem
        },
        model: {
            prop: 'value',
            event: 'input'
        },
        props: {
            placeholder: {
                type: String
            },
            clz: {
                type: String
            },
            value: {
                type: [String, Number, Array]
            },
            data: {
                type: Array,
                default: () => []
            },
            loadData: Function,
            multiple: {
                type: Boolean,
                default: true
            },
            clearable: {
                type: Boolean,
                default: true
            },
            maxTagCount: {
                type: Number,
                default: 1
            }
        },
        data () {
            return {
                isChangedByTree: true,
                isInit: true,
                treeData: this.data
            }
        },
        watch: {
          data(val) {
              this.treeData = val
          }
        },
        computed: {
            selectedArray() {
                return this.multiple ? this.value : []
            },
            selectedData() {
                return this.multiple ? '' : this.value
            }
        },
        provide () {

            return {
                parent: this
            }
        },
        methods: {
            handleChange (selected) {
                if (!this.isChangedByTree) {
                    this.$emit('input', selected)
                }
                this.isChangedByTree = false
            },
            handleTreeCheck (selectedArray) {
                this.isChangedByTree = true
                this.$emit('input', selectedArray.map(item => item.id))
                this.$emit("on-change", selectedArray);
            },
            handleTreeSelect (selected) {
                this.isChangedByTree = true
                this.$emit('input', selected)
                this.$emit('on-select', selected)
            },
            handleClear () {
                this.$refs.select.reset()
            }
        }
    }
</script>

<style lang="less">
    .ivu-tree {
        text-align: left;
    }
    .tree-select {
        .ivu-select-dropdown {
            padding: 0 6px;
        }
    }
</style>
