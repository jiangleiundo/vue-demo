import MoneyInput from './tags-input.vue'
export default MoneyInput
