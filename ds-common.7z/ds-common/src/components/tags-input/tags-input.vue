<template>
    <div :class="clz">
        <Tag v-for="(name, index) in tags" :key="index" :name="name" :closable="!view" class="tag"
             @on-close="handleClose(`${index}`)">{{ name }}
        </Tag>
        <Input v-if="!view" v-model="currentTag" placeholder="添加标签" class="tag-input" @on-blur="handleBlus"></Input>
    </div>
</template>

<script>
    import {Tag, Input} from 'view-design';
    export default {
        name: 'TagsInput',
        components: {
            Tag,
            Input
        },
        props: {
            value: {
                type: String
            },
            clz: {
                type: String
            },
            split: {
                type: String,
                default: ','
            },
            view: {
                type: Boolean,
                default: false
            }
        },
        computed: {},
        data() {
            return {
                tags: [],
                currentTag: ''
            }
        },
        watch: {
            value(val) {
                if (val) {
                    this.tags = val.split(this.split)
                } else {
                    this.tags = []
                }
            }
        },
        methods: {
            getTag() {
                let tagValue = ''
                if (this.tags && this.tags.length > 0) {
                    this.tags.forEach(tag => {
                        if (tagValue) {
                            tagValue += this.split + tag
                        } else {
                            tagValue = tag
                        }
                    })
                }
                return tagValue
            },
            handleBlus() {
                if (this.currentTag) {
                    this.tags.push(this.currentTag)
                    this.currentTag = ''
                    this.$emit('on-change', this.getTag())
                }
            },
            handleClose(index) {
                this.tags.splice(index, 1)
                this.$emit('on-change', this.getTag())
            }
        }
    }
</script>

<style>
    .tag-input.ivu-input-wrapper {
        position: absolute;
        margin-top: 2px;
        width: 100px;
    }

    .tag.ivu-tag {
        height: 32px;
        line-height: 32px;
        border: 1px solid #e8eaec !important;
        color: #515a6e !important;
        background: #fff !important;
    }
</style>
