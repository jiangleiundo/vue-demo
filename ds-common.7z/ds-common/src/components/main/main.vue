<template>
    <Layout style="height: 100%" class="main asp-holy-grail-layout" :style="{paddingLeft: sideMenuWidth}"
            v-bind:class="mainStyle">
        <!-- logo 固定在左上角，菜单超出后滚动 border-right: 1px solid #ddd;-->
        <div class="logo-con j-logo-con" :style="{width: sideMenuWidth}">
                        <span v-show="!collapsed" style="display: inline-block; padding: 0 22px;">
                            <img :src="maxLogo" key="max-logo"/>
                        </span>
            <!--            <img v-show="collapsed" :src="minLogo" key="min-logo"/>-->
        </div>
        <div class="j-side-box" :style="{width: sideMenuWidth}">
            <Sider hide-trigger collapsible :width="sideMenuWidth" :collapsed-width="64" v-model="collapsed"
                   class="left-sider" :style="{overflow: 'hidden', height: '100%'}">
                <side-menu accordion ref="sideMenu" :active-name="$route.name" :collapsed="collapsed"
                           @on-select="turnToPage" :menu-list="menuList">
                    <!--&lt;!&ndash; 需要放在菜单上面的内容，如Logo，写在side-menu标签内部，如下 &ndash;&gt;-->
                    <!--<div class="logo-con" style="position: fixed;top: 0;left: 0;">-->
                    <!--<span v-show="!collapsed" style="display: inline-block; padding: 0 35px; border-right: 1px solid #ddd;">-->
                    <!--<img :src="maxLogo" key="max-logo"/>-->
                    <!--</span>-->
                    <!--<img v-show="collapsed" :src="minLogo" key="min-logo"/>-->
                    <!--</div>-->
                </side-menu>
                <div class="j-side-line"></div>
            </Sider>
            <div :class="{'j-side-menu-arrow': true, 'isShow': isShow}" @click="handleCollpased">
                <i class="ivu-icon ivu-icon-ios-arrow-forward" v-if="isShow"></i>
                <i class="ivu-icon ivu-icon-ios-arrow-back" v-if="!isShow"></i>
            </div>
        </div>
        <Layout class="asp-main-container">
            <Header class="header-con">
                <header-bar :collapsed="collapsed" @on-coll-change="handleCollapsedChange">
                    <!--                    <theme v-if="!$config.noTheme" @on-theme-change="setTheme" :theme="theme"-->
                    <!--                           style="margin-right: 10px;"/>-->
                    <!--                    <language v-if="$config.useI18n" @on-lang-change="setLocal" style="margin-right: 10px;"-->
                    <!--                              :lang="local"/>-->
                    <fullscreen v-model="isFullscreen"/>
                    <div v-if="showMessage" class="message-btn-con">
                        <Tooltip :content="msgContent" placement="bottom">
                            <Badge :count="msgUnreadCount" overflow-count="9" :offset="[26,2]" dot>
                                <Icon @click.native="handleShowMessage" type="md-mail" :size="20"></Icon>
                            </Badge>
                        </Tooltip>
                    </div>
                    <!--                    全屏按钮-->
                    <user :message-unread-count="unreadCount" :user-avatar="userAvatar" style="margin-right: 10px;"/>
                </header-bar>
            </Header>
            <Content class="main-content-con">
                <Layout class="main-layout-con">
                    <div class="tag-nav-wrapper">
                        <tags-nav :value="$route" @input="handleClick" :list="tagNavList" @on-close="handleCloseTag"/>
                    </div>
                    <Content class="content-wrapper">
                        <div class="j-bread-crumb">
                            <custom-bread-crumb :list="breadCrumbList"></custom-bread-crumb>
                        </div>
                        <keep-alive :include="cacheList">
                            <router-view/>
                        </keep-alive>
                        <ABackTop :height="100" :bottom="80" :right="50" container=".content-wrapper"></ABackTop>
                    </Content>
                </Layout>
            </Content>
            <Footer>
                <div class="j-copyright">Copyright &copy; 2020 大连大商商业保理有限公司版权所有</div>
            </Footer>
        </Layout>
    </Layout>
</template>
<script>
    import {Layout, Sider, Header, Content, Tooltip, Badge} from 'view-design';
    import SideMenu from './components/side-menu'
    import HeaderBar from './components/header-bar'
    import customBreadCrumb from './components/header-bar/custom-bread-crumb'
    import TagsNav from './components/tags-nav'
    import User from './components/user'
    import ABackTop from './components/a-back-top'
    import Fullscreen from './components/fullscreen'
    import Language from './components/language'
    import Theme from './components/theme'
    import {mapMutations, mapActions, mapGetters} from 'vuex'
    import {getNewTagList, routeEqual, themeSave, themeRead} from '../../libs/util'
    import config from '@/config'
    import routers from '@/router/routers'
    import minLogo from '@/assets/images/logo-min.jpg'
    import maxLogo from '@/assets/images/homeLogo_03.png'
    import './main.less'

    const {showMessage} = config
    const SIDE_MENU_COMMON_WIDTH = 256;
    const SIDE_MENU_COLLAPSED_WIDTH = 65;

    export default {
        name: 'Main',
        components: {
            Layout,
            Sider,
            Header,
            Content,
            SideMenu,
            HeaderBar,
            customBreadCrumb,
            Language,
            TagsNav,
            Fullscreen,
            Theme,
            User,
            ABackTop,
            Tooltip,
            Badge
        },
        data() {
            return {
                showMessage: showMessage,
                isShow: false, // 收缩
                collapsed: false,
                minLogo,
                maxLogo,
                isFullscreen: false,
                theme: '',
                unreadCount: 0,
                mainStyle: 'asp-theme-primary',
                sideMenuWidth: 256,
                msgCountTimer: null
            }
        },
        computed: {
            tagNavList() {
                return this.$store.state.app.tagNavList
            },
            tagRouter() {
                return this.$store.state.app.tagRouter
            },
            userAvatar() {
                return this.$store.state.user.avatarImgPath
            },
            cacheList() {
                const list = ['ParentView', ...this.tagNavList.length ? this.tagNavList.filter(item => !(item.meta && item.meta.notCache)).map(item => item.name) : []]
                return list
            },
            menuList() {
                return this.$store.getters.menuList
            },
            local() {
                return this.$store.state.app.local
            },
            breadCrumbList() {
                return this.$store.state.app.breadCrumbList
            },
            msgUnreadCount() {
                return this.$store.state.app.msgUnreadCount
            },
            msgContent() {
                let msg = '消息中心'
                if(this.msgUnreadCount > 0) msg += '，' + this.msgUnreadCount + '条未读'
                return msg
            }
        },
        methods: {
            ...mapMutations([
                'setBreadCrumb',
                'setTagNavList',
                'addTag',
                'setHomeRoute',
                'closeTag'
            ]),
            ...mapActions(['getMsgUnreadCount']),
            turnToPage(route) {
                let {name, params, query} = {}
                if (typeof route === 'string') {
                    name = route
                } else {
                    name = route.name
                    params = route.params
                    query = route.query
                }
                if (name.indexOf('isTurnByHref_') > -1) {
                    window.open(name.split('_')[1])
                    return
                }
                this.$router.push({
                    name,
                    params,
                    query
                })
            },
            handleCollapsedChange(state) {
                this.collapsed = state
            },
            handleCloseTag(res, type, route) {
                if (type !== 'others') {
                    if (type === 'all') {
                        this.turnToPage(this.$config.homeName)
                    } else {
                        if (routeEqual(this.$route, route)) {
                            this.closeTag(route)
                        }
                    }
                }
                this.setTagNavList(res)
            },
            handleClick(item) {
                this.turnToPage(item)
            },
            setTheme(theme) {
                if (theme) {
                    this.theme = theme
                    themeSave(theme);
                }
            },
            handleCollpased() {
                this.collapsed = !this.collapsed
                this.isShow = !this.isShow
                if (this.isShow) {
                    this.sideMenuWidth = SIDE_MENU_COLLAPSED_WIDTH - 1 + 'px';
                } else {
                    this.sideMenuWidth = SIDE_MENU_COMMON_WIDTH + 'px';
                }
            },
            handleShowMessage() {
                this.$router.push({
                    name: 'my-message'
                })
            }
        },
        watch: {
            '$route'(newRoute) {
                const {name, query, params, meta} = newRoute
                this.addTag({
                    route: {name, query, params, meta},
                    type: 'push'
                })
                this.setBreadCrumb(newRoute)
                this.setTagNavList(getNewTagList(this.tagNavList, newRoute))
                this.$refs.sideMenu.updateOpenName(newRoute.name)
            }
        },
        created() {
            if(this.showMessage) {
                this.getMsgUnreadCount()
                this.msgCountTimer = setInterval(this.getMsgUnreadCount, 20000)
            }
        },
        mounted() {
            /**
             * @description 初始化设置面包屑导航和标签导航
             */
            this.setTagNavList()
            this.setHomeRoute(routers)
            const {name, params, query, meta} = this.$route
            this.addTag({
                route: {name, params, query, meta}
            })
            this.setBreadCrumb(this.$route)
            // 如果当前打开页面不在标签栏中，跳到homeName页
            if (!this.tagNavList.find(item => item.name === this.$route.name)) {
                this.$router.push({
                    name: this.$config.homeName
                })
            }
            // 设置主题
            let theme = themeRead();
            this.setTheme(theme);
        },
        destroyed() {
            if(this.msgCountTimer) clearInterval(this.msgCountTimer)
        }
    }
</script>

<style lang="less">
    .message-btn-con {
        margin-right: 5px;

        .ivu-tooltip-rel {
            height: 70px;
            line-height: 70px;

            i {
                cursor: pointer;
            }
        }
    }

    .asp-holy-grail-layout {
        padding-left: 256px;
    }

    .asp-main-container {
        width: 100%;
        float: left;
    }

    .main-content-con {
        width: 100%;
    }

    .j-copyright {
        width: 100%;
        position: absolute;
        left: 0;
        bottom: 0;
        z-index: 999999;
        height: 32px;
        line-height: 32px;
        background: #dadada;
        text-align: center;
        font-size: 12px;
    }

    .j-side-line {
        height: 100%;
        width: 1px;
        background: #ccc;
        position: absolute;
        top: 0;
        right: 0;
    }

    .j-logo-con {
        position: fixed;
        top: 0;
        left: 0;
        width: 256px;
    }

    .j-side-box {
        position: fixed;
        width: 256px;
        float: left;
        top: 70px;
        padding-bottom: 100px;
        left: 0;
        height: 100%;
        background: #fff;
        transition: width .2s ease-in-out;

        .j-side-menu-arrow {
            width: 11px;
            height: 90px;
            line-height: 90px;
            border: 1px solid #ccc;
            border-left-color: #e7e7e7;
            border-top-right-radius: 5px;
            border-bottom-right-radius: 5px;
            background: #e7e7e7;
            position: absolute;
            top: 50%;
            right: -10px;
            margin-top: -100px;
            z-index: 999;

            &:hover {
                cursor: pointer;
            }

            .ivu-icon {
                color: #666;
                font-size: 14px;
                margin-left: -3px;
            }
        }

        .isShow {
            border-left-color: #fff;
            background: #fff;

            .ivu-icon {
                color: #e8313e;
            }
        }
    }

    .j-bread-crumb {
        padding: 10px 0 10px 15px;
        margin-top: -15px;
    }

</style>

