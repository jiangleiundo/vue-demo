import Main from './main.vue'
export default Main
