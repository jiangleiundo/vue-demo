<template>
    <div>
        <Dropdown trigger="click" @on-click="selectTheme">
            <a href="javascript:void(0)" class="asp-topbar-text">
                风格
                <Icon :size="18" type="md-arrow-dropdown"/>
            </a>
            <DropdownMenu slot="list">
                <DropdownItem v-for="(value, key) in themeList" :name="key" :key="`theme-${key}`">{{ value }}
                </DropdownItem>
            </DropdownMenu>
        </Dropdown>
    </div>
</template>

<script>
    import {Dropdown, DropdownMenu, DropdownItem, Icon} from 'view-design';
    import {themeSave} from '../../../../libs/util'

    export default {
        name: 'theme',
        components: {
            Dropdown,
            DropdownMenu,
            DropdownItem,
            Icon
        },
        inject: ['reload'],
        props: {
            theme: String
        },
        data() {
            return {
                themeList: {
                    '1': '弹出-手风琴',
                    '2': '弹出-TAB页',
                    '3': '抽屉-手风琴',
                    '4': '抽屉-TAB页'
                }
            }
        },
        watch: {
            theme(theme) {
                themeSave(theme);
                this.$emit('on-theme-change', name)
            }
        },
        computed: {},
        methods: {
            selectTheme(name) {
                this.$emit('on-theme-change', name)
                this.reload()
            }
        }
    }
</script>
<style lang="less">
    @import '../../../../styles/variables.less';

    .asp-topbar-text {
        color: #000;

        &:hover {
            color: @primary-color;
        }
    }
</style>
