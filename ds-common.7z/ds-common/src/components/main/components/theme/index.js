import Theme from './theme.vue'
export default Theme
