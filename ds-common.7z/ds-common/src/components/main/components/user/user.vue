<template>
    <div>
        <div class="user-avatar-dropdown">
            <span style="font-size: 14px;margin-right: 15px">当前营业日：{{bussDate}}</span>
            <span v-if="showDepart" style="font-size: 14px;margin-right: 15px">所属部门：{{userDepartName}}</span>
<!--            <span style="font-size: 14px;margin-right: 15px"> {{userProvinceName}}</span>-->
            <Dropdown v-if="showRoles" @on-click="handleClickRole" style="margin-right: 15px">
                <Badge>
                    <span style="font-size: 14px;">{{userRoleName}}</span>
                </Badge>
                <Icon :size="18" type="md-arrow-dropdown"></Icon>
                <DropdownMenu slot="list" v-for="role in userRoleList">
                    <DropdownItem :name="role.name">{{role.name}}</DropdownItem>
                </DropdownMenu>
            </Dropdown>
            <Dropdown @on-click="handleClick">
                <Badge :dot="!!messageUnreadCount">
<!--                    <Icon :size="25" type="md-person" color="#e8313e"></Icon>-->
                    <span style="font-size: 14px;">{{userName}}</span>
                </Badge>
                <Icon :size="18" type="md-arrow-dropdown"></Icon>
                <DropdownMenu slot="list">
<!--                    <DropdownItem v-if="showMessage" name="message">-->
<!--                        消息中心-->
<!--                        <Badge style="margin-left: 10px" :count="messageUnreadCount"></Badge>-->
<!--                    </DropdownItem>-->
                    <DropdownItem v-if="showUpdatePassword" name="updatePassword">修改密码</DropdownItem>
                    <DropdownItem name="logout">退出登录</DropdownItem>
                </DropdownMenu>
            </Dropdown>
        </div>

        <MainForm title="修改密码" v-model="updatePasswordShow" ref="updatePasswordRef" :data="user" :width="430"
                  :rules="updatePasswordValidate" formType="2" @on-cancel="updatePasswordShow = false">
            <div slot="form-main">
                <Row>
                    <FormItem label="原密码" prop="oldPassword">
                        <Input type="password" v-model="user.oldPassword" placeholder="请输入原密码"
                               class="form-input"></Input>
                    </FormItem>
                </Row>
                <Row>
                    <FormItem label="新密码" prop="password">
                        <Input type="password" v-model="user.password" placeholder="请输入新密码"
                               class="form-input"></Input>
                    </FormItem>
                </Row>
            </div>
            <div slot="form-btn">
                <Button class="r-btn" type="primary" @click="updatePasswordSubmit">提交</Button>
                <Button @click="updatePasswordShow = false">关闭</Button>
            </div>
        </MainForm>
    </div>
</template>

<script>
    import {Dropdown, Badge, Avatar, Icon, DropdownMenu, DropdownItem, Row, FormItem, Input, Button} from 'view-design';
    import './user.less'
    import config from '@/config'
    import MainForm from '../../../main-form'
    import {mapActions, mapMutations} from 'vuex'
    import {bussDate} from '../../../../libs/api.utils.js'

    const {showUpdatePassword, showRoles, showDepart, showMessage} = config

    export default {
        name: 'User',
        components: {
            Dropdown,
            Badge,
            Avatar,
            Icon,
            DropdownMenu,
            DropdownItem,
            Row,
            FormItem,
            Input,
            Button,
            MainForm
        },
        props: {
            userAvatar: {
                type: String,
                default: ''
            },
            messageUnreadCount: {
                type: Number,
                default: 0
            }
        },
        computed: {
            bussDate() {
                return bussDate()
            },
            userName() {
                let name = ''
                if (this.$store.state.user.user) {
                    if(this.$store.state.user.user.seller) {
                        name = this.$store.state.user.user.seller.sellerName
                    } else {
                        name = this.$store.state.user.user.name || this.$store.state.user.user.userName
                    }
                }
                return name
            },
            userDepartName() {
                let name = ''
                if (this.$store.state.user.user) {
                    name = this.$store.state.user.user.sysDepartInfo && this.$store.state.user.user.sysDepartInfo.departName
                }
                return name
            },
            userProvinceName() {
                let name = ''
                if (this.$store.state.user.user) {
                    name = this.$store.state.user.user.provinceName || ''
                }
                return name
            },
            userRoleList() {
                let roleList = this.$store.state.user.user ? this.$store.state.user.user.sysRoleList : []
                if (roleList && roleList.length > 0) {
                    roleList = roleList.filter(o => {
                        return o.name != this.userRoleName
                    })
                } else {
                    roleList = []
                }
                return roleList
            }
        },
        data() {
            return {
                showUpdatePassword: showUpdatePassword,
                showRoles: showRoles,
                showDepart: showDepart,
                updatePasswordShow: false,
                showMessage: showMessage,
                user: {},
                updatePasswordValidate: {
                    oldPassword: [
                        {required: true, message: '请输入原密码', trigger: 'blur'}
                    ],
                    password: [
                        {required: true, message: '请输入新密码', trigger: 'blur'}
                    ]
                },
                userRoleId: this.$store.state.user.user && this.$store.state.user.user.sysRole ? this.$store.state.user.user.sysRole.roleId : '',
                userRoleName: this.$store.state.user.user && this.$store.state.user.user.sysRole ? this.$store.state.user.user.sysRole.name : ''
            }
        },
        inject: ['reload'],
        methods: {
            ...mapActions([
                'handleLogin',
                'handleLogOut',
                'handleUpdatePassword'
            ]),
            ...mapMutations([
                'setTagNavList'
            ]),
            logout() {
                this.handleLogOut().then(() => {
                    this.$router.push({
                        name: 'login'
                    })
                })
            },
            updatePassword() {
                this.updatePasswordShow = true
            },
            updatePasswordSubmit() {
                let vm = this
                vm.$refs.updatePasswordRef.validate((valid) => {
                    if (valid) {
                        vm.handleUpdatePassword(vm.user).then(res => {
                            if (res.success) {
                                vm.logout()
                            }
                        })
                    }
                })
            },
            message() {
                this.$router.push({
                    name: 'my-message'
                })
            },
            handleClick(name) {
                switch (name) {
                    case 'logout':
                        this.logout()
                        break
                    case 'message':
                        this.message()
                        break
                    case 'updatePassword':
                        this.updatePassword()
                        break
                }
            },
            handleClickRole (name) {
                let vm = this
                let role = null
                let roleList = vm.userRoleList
                if (roleList && roleList.length > 0) {
                    roleList.some(o => {
                        if (o.name == name) {
                            role = o
                            return true
                        }
                    })
                }
                if (role) {
                    vm.$request({
                        url: '/api/admin/base/change-sys-role',
                        data: role,
                        success: res => {
                            let user = res.data
                            vm.$store.state.user.user = user
                            vm.handleLogin(user)
                            if(user.sysRole) {
                                vm.userRoleId = user.sysRole.roleId
                                vm.userRoleName = user.sysRole.name
                            }
                            vm.$router.push({name: 'home'})
                        }
                    })
                }
            }
        }
    }
</script>
