import RateInput from './rate-input.vue'
export default RateInput
