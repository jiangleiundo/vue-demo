import Title from './title.vue'
export default Title
