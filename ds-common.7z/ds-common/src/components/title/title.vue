<template>
    <div class="j-param-tit"  :title="curTit">
        <span class="dot"></span>
        <h3 class="tit">
            {{curTit}}
            <slot></slot>
        </h3>
        <div class="fl-r right">
            <slot name="right"></slot>
        </div>
    </div>
</template>
<script>
    export default {
        components: {},
        name: 'Title',
        props: {
            title: {
                type: String,
            },
        },
        data() {
            return {
                curTit: this.title,
            }
        },
        watch: {
            title(val) {
                this.curTit = val
            }
        },
        methods: {},
        mounted() {}
    }
</script>
<style lang="less" scoped>

    .j-param-tit {
        height: 35px;
        line-height: 35px;
        border-bottom: 2px solid #ba9759;
        margin-bottom: 10px;
        margin-left: 8px;
        .dot {
            display: inline-block;
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background: #ba9759;
            vertical-align: -1px;
            margin-right: 8px;
        }
        .tit {
            display: inline-block;
        }
    }

    right {
        margin-right: 20px;
    }
</style>
