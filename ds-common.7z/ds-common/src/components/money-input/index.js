import MoneyInput from './money-input.vue'
export default MoneyInput
